# Smart Waste Management System Deployment Guide

## 1. Hardware Installation

### 1.1 Smart Bin Modules
1. Assemble sensor components in weatherproof enclosure
2. Mount ultrasonic sensor at top of bin pointing downward
3. Install load cell under bin base
4. Secure solar panel to bin lid
5. Program ESP32 with provided firmware
6. Deploy bins at designated locations

### 1.2 Gateway Installation
1. Install LoRaWAN gateways on streetlights/buildings
   - Minimum density: 1 gateway per 2 sq km
2. Connect to power and network infrastructure
3. Configure gateway settings

## 2. Cloud Infrastructure Setup

### 2.1 AWS Configuration
```bash
# Create IoT Core policy
aws iot create-policy --policy-name WasteBinPolicy \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Action": "iot:*",
      "Resource": "*"
    }]
  }'

# Create IoT Thing Type
aws iot create-thing-type --thing-type-name SmartWasteBin

# Provision certificates for devices
```

### 2.2 Database Setup
```bash
# Create InfluxDB database
influx -execute "CREATE DATABASE waste_management"
influx -execute "CREATE RETENTION POLICY one_year ON waste_management DURATION 52w REPLICATION 1"
```

## 3. Software Deployment

### 3.1 Backend Services
```bash
# Clone repository
git clone https://github.com/your-repo/smart-waste-management.git
cd smart-waste-management/cloud

# Install dependencies
pip install -r requirements.txt

# Start services
nohup python route_optimizer.py &
nohup python alert_service.py &
```

### 3.2 Web Dashboard
```bash
cd ../web_dashboard
npm install
npm run build
serve -s build -l 3000
```

## 4. System Testing

1. Verify sensor data is being received:
```bash
influx -database 'waste_management' -execute 'SELECT * FROM bin_metrics LIMIT 10'
```

2. Test route optimization:
```bash
curl -X POST http://localhost:5000/optimize-routes
```

3. Verify dashboard access:
   - Open browser to http://your-server:3000

## 5. Maintenance

### 5.1 Firmware Updates
```bash
# Compile new firmware
platformio run

# Distribute OTA update
python ota_deploy.py --bin-file .pio/build/esp32/firmware.bin
```

### 5.2 Data Backup
```bash
# Daily database backup
influxd backup -portable -database waste_management /backups/waste_management
```

## 6. Scaling City-wide

1. Phase 1: Pilot in 3 wards (100 bins)
2. Phase 2: Expand to 30 wards (1,000 bins)
3. Phase 3: Full city deployment (10,000+ bins)
   - Add regional data processing nodes
   - Implement microservices architecture
   - Deploy additional gateways
