import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Chart } from 'react-google-charts';

// Bin status icons
const icons = {
  empty: new L.Icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/1828/1828640.png',
    iconSize: [25, 25]
  }),
  half: new L.Icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/1828/1828643.png',
    iconSize: [25, 25]
  }),
  full: new L.Icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/1828/1828664.png',
    iconSize: [25, 25]
  })
};

function App() {
  const [bins, setBins] = useState([]);
  const [selectedBin, setSelectedBin] = useState(null);
  const [routes, setRoutes] = useState([]);

  useEffect(() => {
    // Fetch bin data from API
    const fetchData = async () => {
      const response = await fetch('/api/bins');
      const data = await response.json();
      setBins(data);
    };
    fetchData();
    const interval = setInterval(fetchData, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, []);

  const getBinIcon = (fillLevel) => {
    if (fillLevel < 30) return icons.empty;
    if (fillLevel < 70) return icons.half;
    return icons.full;
  };

  const generateRoute = async () => {
    const response = await fetch('/api/optimize-routes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();
    setRoutes(data.routes);
  };

  return (
    <div className="dashboard">
      <div className="map-container">
        <MapContainer 
          center={[20.2961, 85.8245]} 
          zoom={13} 
          style={{ height: '100vh', width: '70%' }}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {bins.map(bin => (
            <Marker
              key={bin.id}
              position={[bin.latitude, bin.longitude]}
              icon={getBinIcon(bin.fill_level)}
              eventHandlers={{
                click: () => setSelectedBin(bin)
              }}
            >
              <Popup>
                <div>
                  <h3>Bin {bin.id}</h3>
                  <p>Fill Level: {bin.fill_level}%</p>
                  <p>Weight: {bin.weight} kg</p>
                  <p>Last Collected: {new Date(bin.last_collected).toLocaleString()}</p>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
      
      <div className="sidebar">
        <div className="control-panel">
          <button onClick={generateRoute}>Optimize Routes</button>
          {routes.length > 0 && (
            <div className="routes">
              <h3>Optimized Routes</h3>
              {routes.map((route, i) => (
                <div key={i} className="route">
                  <h4>Vehicle {i+1}</h4>
                  <ol>
                    {route.map(binId => (
                      <li key={binId}>{binId}</li>
                    ))}
                  </ol>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {selectedBin && (
          <div className="bin-details">
            <h2>Bin {selectedBin.id}</h2>
            <Chart
              chartType="Gauge"
              width="100%"
              height="200px"
              data={[
                ['Label', 'Value'],
                ['Fill Level', selectedBin.fill_level]
              ]}
              options={{
                redFrom: 90,
                redTo: 100,
                yellowFrom: 70,
                yellowTo: 90,
                minorTicks: 5
              }}
            />
            <div className="sensor-data">
              <p><strong>Temperature:</strong> {selectedBin.temperature}°C</p>
              <p><strong>Battery Level:</strong> {selectedBin.battery_level}%</p>
              <p><strong>Last Updated:</strong> {new Date(selectedBin.last_updated).toLocaleString()}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
