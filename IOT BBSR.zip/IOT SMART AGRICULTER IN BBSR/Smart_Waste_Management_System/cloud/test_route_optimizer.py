from route_optimizer_corrected import WasteRouteOptimizer
import time

def test_optimizer():
    print("=== Testing Waste Route Optimizer ===")
    
    # Initialize optimizer
    optimizer = WasteRouteOptimizer()
    
    # Test data - 5 sample bins around Bhubaneswar
    test_bins = [
        {
            'device_id': 'bin_001',
            'latitude': 20.2961,
            'longitude': 85.8245,
            'fill_level': 85,
            'weight': 120
        },
        {
            'device_id': 'bin_002',
            'latitude': 20.2910,
            'longitude': 85.8336,
            'fill_level': 65,
            'weight': 90
        },
        {
            'device_id': 'bin_003',
            'latitude': 20.3015,
            'longitude': 85.8172,
            'fill_level': 95,
            'weight': 150
        },
        {
            'device_id': 'bin_004',
            'latitude': 20.2854,
            'longitude': 85.8268,
            'fill_level': 45,
            'weight': 60
        },
        {
            'device_id': 'bin_005',
            'latitude': 20.3050,
            'longitude': 85.8300,
            'fill_level': 75,
            'weight': 110
        }
    ]
    
    # Test 1: Basic functionality
    print("\nTest 1: Adding bins and optimizing routes")
    for bin_data in test_bins:
        optimizer.update_bin_data(bin_data)
    
    start_time = time.time()
    routes = optimizer.optimize_routes(vehicles=2)
    duration = time.time() - start_time
    
    print(f"Optimization completed in {duration:.2f} seconds")
    print("Generated routes:")
    for i, route in enumerate(routes, 1):
        print(f"Vehicle {i}: {route}")
    
    # Test 2: Error handling
    print("\nTest 2: Error handling - empty bin data")
    empty_optimizer = WasteRouteOptimizer()
    try:
        empty_optimizer.optimize_routes()
    except Exception as e:
        print(f"Expected error caught: {str(e)}")
    
    print("\nTest 3: Error handling - invalid payload")
    try:
        optimizer.update_bin_data({'invalid': 'data'})
    except Exception as e:
        print(f"Expected error caught: {str(e)}")

if __name__ == "__main__":
    test_optimizer()
