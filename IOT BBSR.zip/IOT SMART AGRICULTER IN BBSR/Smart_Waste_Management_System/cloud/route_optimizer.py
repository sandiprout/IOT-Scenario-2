import json
import numpy as np
import logging
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
from datetime import datetime, timedelta
import pytz
from math import radians, sin, cos, sqrt, atan2

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WasteRouteOptimizer:
    def __init__(self, config=None):
        self.bin_data = {}
        self.config = config or {
            'vehicle_capacity': 1000,  # kg
            'time_window': 8 * 3600,  # 8 hours in seconds
            'vehicle_speed': 30,  # km/h
            'collection_time': 300,  # 5 minutes
            'depot_location': (20.2961, 85.8245)  # Bhubaneswar coordinates
        }
        self.validate_config()

    def validate_config(self):
        """Validate configuration parameters"""
        if not all(isinstance(v, (int, float)) for v in self.config.values()):
            raise ValueError("Invalid config parameter types")
        if self.config['vehicle_capacity'] <= 0:
            raise ValueError("Vehicle capacity must be positive")

    def update_bin_data(self, payload):
        """Update bin status from IoT messages with validation"""
        try:
            required_fields = ['device_id', 'latitude', 'longitude', 
                             'fill_level', 'weight']
            if not all(field in payload for field in required_fields):
                raise ValueError("Missing required fields in payload")
            
            bin_id = payload['device_id']
            self.bin_data[bin_id] = {
                'location': (float(payload['latitude']), 
                           float(payload['longitude'])),
                'fill_level': float(payload['fill_level']),
                'weight': float(payload['weight']),
                'last_updated': datetime.now(pytz.timezone('Asia/Kolkata')),
                'last_collected': payload.get('last_collected'),
                'priority': self._calculate_priority(payload)
            }
            logger.info(f"Updated bin {bin_id} data")
        except (ValueError, TypeError) as e:
            logger.error(f"Invalid payload data: {e}")

    def _calculate_priority(self, payload):
        """Enhanced priority calculation with time decay factor"""
        fill_weight = 0.6 * payload['fill_level'] + 0.4 * payload['weight']
        
        # Time decay factor (higher priority if not collected recently)
        last_collected = payload.get('last_collected')
        if last_collected:
            hours_since = (datetime.now(pytz.timezone('Asia/Kolkata')) - 
                          last_collected).total_seconds() / 3600
            time_factor = min(2.0, 1 + (hours_since / 24))  # Max 2x multiplier
        else:
            time_factor = 2.0  # Never collected gets highest priority
            
        return min(100, fill_weight * time_factor)

    def _haversine_distance(self, coord1, coord2):
        """Calculate distance between two coordinates in km"""
        lat1, lon1 = radians(coord1[0]), radians(coord1[1])
        lat2, lon2 = radians(coord2[0]), radians(coord2[1])
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return 6371 * c  # Earth radius in km

    def _create_distance_matrix(self, locations):
        """Create complete distance matrix using Haversine formula"""
        size = len(locations)
        matrix = np.zeros((size, size))
        
        for i in range(size):
            for j in range(size):
                if i == j:
                    matrix[i][j] = 0
                else:
                    matrix[i][j] = self._haversine_distance(locations[i], locations[j])
        
        return matrix.tolist()

    def optimize_routes(self, vehicles=5):
        """Generate optimized collection routes with error handling"""
        try:
            if not self.bin_data:
                raise ValueError("No bin data available for optimization")
                
            locations = [self.config['depot_location']] + \
                       [data['location'] for data in self.bin_data.values()]
            priorities = [0] + [data['priority'] for data in self.bin_data.values()]
            
            distance_matrix = self._create_distance_matrix(locations)
            
            # Convert distances to time in seconds
            time_matrix = [[int(d * 3600 / self.config['vehicle_speed']) 
                          for d in row] for row in distance_matrix]
            
            manager = pywrapcp.RoutingIndexManager(
                len(locations), vehicles, 0)  # Depot at index 0
            routing = pywrapcp.RoutingModel(manager)
            
            # Add time dimension
            transit_callback_index = routing.RegisterTransitCallback(
                lambda i, j: time_matrix[i][j])
            routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
            
            # Add priority constraint
            def priority_callback(from_index):
                from_node = manager.IndexToNode(from_index)
                return priorities[from_node]
                
            priority_index = routing.RegisterUnaryTransitCallback(priority_callback)
            routing.AddDimensionWithVehicleCapacity(
                priority_index,
                0,  # null capacity slack
                [self.config['vehicle_capacity']] * vehicles,
                True,  # start cumul to zero
                'Priority')
            
            # Add time window constraint
            routing.AddDimension(
                transit_callback_index,
                0,  # allow waiting time
                self.config['time_window'],  # maximum time per vehicle
                False,  # don't force start cumul to zero
                'Time')
            
            # Solve with multiple strategies
            search_parameters = pywrapcp.DefaultRoutingSearchParameters()
            search_parameters.time_limit.seconds = 30
            search_parameters.first_solution_strategy = (
                routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
            search_parameters.local_search_metaheuristic = (

if __name__ == "__main__":
    optimizer = WasteRouteOptimizer()
    # Sample data update
    optimizer.update_bin_data({
        'device_id': 'bin_001',
        'latitude': 20.2961,
        'longitude': 85.8245,
        'fill_level': 85,
        'weight': 120
    })
    routes = optimizer.optimize_routes()
    print("Optimized Routes:", routes)
