import json
import numpy as np
from math import radians, sin, cos, sqrt, atan2
from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
from datetime import datetime, timedelta
import pytz

class WasteRouteOptimizer:
    """Optimizes waste collection routes using vehicle routing algorithms."""
    
    def __init__(self):
        """Initialize the route optimizer with default parameters."""
        self.bin_data = {}
        self.vehicle_capacity = 1000  # kg
        self.time_window = 8 * 3600  # 8 hours in seconds
        self.vehicle_speed = 30  # km/h
        self.collection_time_per_bin = 300  # 5 minutes in seconds

    def update_bin_data(self, payload):
        """
        Update bin status from IoT messages.
        
        Args:
            payload (dict): Must contain:
                - device_id: Unique bin identifier
                - latitude: GPS latitude
                - longitude: GPS longitude
                - fill_level: Percentage full (0-100)
                - weight: Current weight in kg
        """
        if not all(key in payload for key in ['device_id', 'latitude', 'longitude', 'fill_level', 'weight']):
            raise ValueError("Payload missing required fields")
            
        bin_id = payload['device_id']
        self.bin_data[bin_id] = {
            'location': (payload['latitude'], payload['longitude']),
            'fill_level': payload['fill_level'],
            'weight': payload['weight'],
            'last_updated': datetime.now(pytz.timezone('Asia/Kolkata')),
            'priority': self._calculate_priority(payload)
        }

    def _calculate_priority(self, payload):
        """
        Calculate collection priority (0-100) based on fill level and weight.
        
        Args:
            payload (dict): Bin data payload
            
        Returns:
            float: Priority score between 0-100
        """
        fill_weight = 0.6 * payload['fill_level'] + 0.4 * payload['weight']
        time_factor = 1.0  # Can be adjusted based on last collection time
        return min(100, fill_weight * time_factor)

    def optimize_routes(self, vehicles=5):
        """
        Generate optimized collection routes using OR-Tools.
        
        Args:
            vehicles (int): Number of available vehicles
            
        Returns:
            list: List of routes (each route is a list of bin IDs)
        """
        if not self.bin_data:
            raise ValueError("No bin data available for optimization")
            
        locations = [data['location'] for data in self.bin_data.values()]
        priorities = [data['priority'] for data in self.bin_data.values()]
        
        # Create distance matrix
        distance_matrix = self._create_distance_matrix(locations)
        
        # Create routing model
        manager = pywrapcp.RoutingIndexManager(
            len(locations), vehicles, 0)  # 0 is depot index
        routing = pywrapcp.RoutingModel(manager)
        
        # Add distance constraint with safe indexing
        def safe_distance_callback(i, j):
            """Safe wrapper for distance matrix access"""
            try:
                i = int(i)  # Convert to standard int first
                j = int(j)
                if 0 <= i < len(distance_matrix) and 0 <= j < len(distance_matrix[i]):
                    return distance_matrix[i][j]
                return 0  # Return 0 for invalid indices
            except Exception as e:
                print(f"Warning in distance callback: {str(e)}")
                return 0
                
        transit_callback_index = routing.RegisterTransitCallback(safe_distance_callback)
        routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
        
        # Add capacity constraint with safe indexing
        def safe_priority_callback(i):
            """Safe wrapper for priority access"""
            try:
                i = int(i)
                if 0 <= i < len(priorities):
                    return priorities[i]
                return 0  # Return 0 for invalid indices
            except Exception as e:
                print(f"Warning in priority callback: {str(e)}")
                return 0
                
        demand_callback_index = routing.RegisterUnaryTransitCallback(safe_priority_callback)
        routing.AddDimensionWithVehicleCapacity(
            demand_callback_index,
            0,  # null capacity slack
            [self.vehicle_capacity] * vehicles,  # vehicle capacities
            True,  # start cumul to zero
            'Capacity')
            
        # Add time dimension (considering vehicle speed and collection time)
        def time_callback(from_index, to_index):
            """Calculate travel time between locations in seconds."""
            try:
                # Convert indices safely with direct casting
                from_node = manager.IndexToNode(int(float(from_index)))
                to_node = manager.IndexToNode(int(float(to_index)))
                if from_node == to_node:
                    return 0
                if (0 <= from_node < len(distance_matrix) and 
                    0 <= to_node < len(distance_matrix[from_node])):
                    distance = distance_matrix[from_node][to_node]  # in km
                    travel_time = (distance / self.vehicle_speed) * 3600  # in seconds
                    return int(travel_time + self.collection_time_per_bin)
                return 0  # Return 0 for invalid indices
            except Exception as e:
                print(f"Warning in time callback: {str(e)}")
                return 0
                
        time_callback_index = routing.RegisterTransitCallback(time_callback)
        routing.AddDimension(
            time_callback_index,
            0,  # allow waiting time
            self.time_window,  # maximum time per vehicle
            False,  # don't force start cumul to zero
            'Time')
        
        # Solve
        search_parameters = pywrapcp.DefaultRoutingSearchParameters()
        search_parameters.first_solution_strategy = (
            routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
        solution = routing.SolveWithParameters(search_parameters)
        
        if not solution:
            raise RuntimeError("No solution found for the given constraints")
        
        # Extract routes with global duplicate prevention
        routes = []
        all_visited_bins = set()
        
        for vehicle_id in range(vehicles):
            index = routing.Start(vehicle_id)
            route = []
            while not routing.IsEnd(index):
                bin_idx = manager.IndexToNode(index)
                bin_id = list(self.bin_data.keys())[bin_idx]
                if bin_id not in all_visited_bins:
                    route.append(bin_id)
                    all_visited_bins.add(bin_id)
                index = solution.Value(routing.NextVar(index))
            
            if route:  # Only add non-empty routes
                routes.append(route)
            
        return routes

    def _create_distance_matrix(self, locations):
        """
        Create distance matrix using Haversine formula.
        
        Args:
            locations (list): List of (latitude, longitude) tuples
            
        Returns:
            list: 2D matrix of distances in kilometers
        """
        matrix = []
        for i, (lat1, lon1) in enumerate(locations):
            row = []
            for j, (lat2, lon2) in enumerate(locations):
                if i == j:
                    row.append(0)
                    continue
                    
                # Haversine formula
                R = 6371  # Earth radius in km
                dlat = radians(lat2 - lat1)
                dlon = radians(lon2 - lon1)
                a = (sin(dlat/2) * sin(dlat/2) + 
                     cos(radians(lat1)) * cos(radians(lat2)) * 
                     sin(dlon/2) * sin(dlon/2))
                c = 2 * atan2(sqrt(a), sqrt(1-a))
                distance = R * c
                row.append(distance)
            matrix.append(row)
        return matrix

if __name__ == "__main__":
    optimizer = WasteRouteOptimizer()
    # Sample data update
    optimizer.update_bin_data({
        'device_id': 'bin_001',
        'latitude': 20.2961,
        'longitude': 85.8245,
        'fill_level': 85,
        'weight': 120
    })
    try:
        routes = optimizer.optimize_routes()
        print("Optimized Routes:", routes)
    except Exception as e:
        print(f"Route optimization failed: {str(e)}")
