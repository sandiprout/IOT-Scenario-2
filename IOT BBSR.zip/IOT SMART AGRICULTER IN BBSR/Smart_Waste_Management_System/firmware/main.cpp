#include <Arduino.h>
#include <LoRa.h>
#include <HX711.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// Sensor pins
#define LOADCELL_DOUT_PIN 4
#define LOADCELL_SCK_PIN 5
#define TRIGGER_PIN 12
#define ECHO_PIN 13
#define TEMP_PIN 14
#define LORA_CS 18
#define LORA_RST 14
#define LORA_IRQ 26

HX711 scale;
OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);

struct SensorData {
  float fillLevel;    // Percentage (0-100)
  float weight;       // Kilograms
  float temperature;  // Celsius
  float batteryLevel; // Percentage (0-100)
};

void setup() {
  Serial.begin(115200);
  
  // Initialize sensors
  scale.begin(LOADCELL_DOUT_PIN, LOADCELL_SCK_PIN);
  tempSensor.begin();
  pinMode(TRIGGER_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  
  // Initialize LoRa
  LoRa.setPins(LORA_CS, LORA_RST, LORA_IRQ);
  if (!LoRa.begin(868E6)) {
    Serial.println("LoRa init failed!");
    while (1);
  }
}

float measureFillLevel() {
  digitalWrite(TRIGGER_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIGGER_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIGGER_PIN, LOW);
  
  long duration = pulseIn(ECHO_PIN, HIGH);
  float distance = duration * 0.034 / 2;
  return (1 - (distance / 100.0)) * 100; // Assuming 100cm bin height
}

void loop() {
  SensorData data;
  
  // Read sensors
  data.fillLevel = measureFillLevel();
  data.weight = scale.get_units(10);
  tempSensor.requestTemperatures();
  data.temperature = tempSensor.getTempCByIndex(0);
  data.batteryLevel = analogRead(A0) * 100.0 / 1023.0;
  
  // Send data via LoRa
  LoRa.beginPacket();
  LoRa.write((uint8_t*)&data, sizeof(data));
  LoRa.endPacket();
  
  delay(60000); // Send data every minute
}
